package com.example.scrool

data class Comida(
    val name: String,
    val country: String,
    val foodImageResId: Int,
    val countryImageResId: Int,
    val description: String
)

